<?php

namespace Database\Seeders;

use App\Models\MercadoLibreToken;
use Illuminate\Database\Seeder;

class MercadoLibreTokenSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $this->personal();
    }

    function personal() {
        
        MercadoLibreToken::create([
            'user_id'           => env('USER_ID'),
            'meli_user_id'      => '163250661',
            'access_token'      => 'APP_USR-6355072095226922-100312-8f64d543fbf8e5ecadd908e68c6c9c42-163250661',
            'refresh_token'     => 'TG-68dff3da841be70001f57134-163250661',
            'expires_at'        => '2025-10-03 19:13:50',
        ]);

    }

    function leudinox() {
        
        MercadoLibreToken::create([
            'user_id'           => env('USER_ID'),
            'meli_user_id'      => '41181056',
            'access_token'      => 'APP_USR-6355072095226922-100311-1333dd343d929b37082cbd7eb8a24424-41181056',
            'refresh_token'     => 'TG-68dfe95a20330700014fecc8-41181056',
            'expires_at'        => '2025-10-03 18:18:50',
        ]);

    }
}
