<?php

$sub_categories = [
    [
        'category_name'     => 'Vinos',
        'category_id'       => 1,
        'sub_categories'    => [
            'Importados',
            'Locales',
        ],
    ],
    [
        'category_name'     => 'Espumantes',
        'category_id'       => 2,
        'sub_categories'    => [
            'Importados',
            'Locales',
        ],
    ],
];