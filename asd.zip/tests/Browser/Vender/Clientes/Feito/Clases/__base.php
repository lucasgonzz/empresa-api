<?php

namespace Tests\Browser\Vender\Clientes\Feito\Clases;

class __base {

    public function __construct($browser) {
        
        $this->browser = $browser;

    }

}
