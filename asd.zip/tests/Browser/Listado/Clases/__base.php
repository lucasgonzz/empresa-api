<?php

namespace Tests\Browser\Listado\Clases;

class __base {

    function __construct($browser) {

        $this->browser = $browser;

    }
    
}
