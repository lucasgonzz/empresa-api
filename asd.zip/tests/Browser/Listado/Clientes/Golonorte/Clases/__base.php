<?php

namespace Tests\Browser\Listado\Clientes\Golonorte\Clases;

class __base {

    public function __construct($browser) {
        
        $this->browser = $browser;

    }

}
