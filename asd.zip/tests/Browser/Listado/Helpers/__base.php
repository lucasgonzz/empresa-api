<?php

namespace Tests\Browser\Listado\Helpers;

class __base {

    function __construct($browser) {

        $this->browser = $browser;

    }
    
}
