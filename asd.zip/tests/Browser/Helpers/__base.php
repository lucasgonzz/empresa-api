<?php

namespace Tests\Browser\Helpers;

class __base {

    function __construct($browser) {

        $this->browser = $browser;

    }
    
}
