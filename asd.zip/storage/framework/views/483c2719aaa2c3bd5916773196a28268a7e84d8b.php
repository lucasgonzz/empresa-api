<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Configurador de extenciones</title>
    <style>
        body {
            background-color: #f0f2f5;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px 0;
        }

        .container {
            width: 100%;
            margin: 30px 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .form-box {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        h1 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        label {
            display: block;
            margin-top: 15px;
            color: #333;
        }

        input[type="checkbox"] {
            margin-right: 10px;
        }

        button {
            margin-top: 20px;
            width: 100%;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .status {
            color: green;
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="form-box">
        <h1>Extenciones de <?php echo e($user->name); ?></h1>

        <?php if(session('success')): ?>
            <p class="status"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('users.extencions.update', $user->id)); ?>">
            <?php echo csrf_field(); ?>

            <?php $__currentLoopData = $extencions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extencion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label>
                    <input
                        type="checkbox"
                        name="extencions[]"
                        value="<?php echo e($extencion->id); ?>"
                        <?php echo e(in_array($extencion->id, $user_extencion_ids) ? 'checked' : ''); ?>

                    >
                    <?php echo e($extencion->name); ?>

                </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <button type="submit">Guardar extenciones</button>
        </form>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\wamp64\www\empresa-api\resources\views/user/extencions/edit.blade.php ENDPATH**/ ?>