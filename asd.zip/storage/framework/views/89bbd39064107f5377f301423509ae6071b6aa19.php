<?php $__env->startComponent('mail::layout'); ?>

<?php $__env->slot('header'); ?>

<?php $__env->startComponent('mail::header', ['url' => $user->online]); ?>
<img src="<?php echo e($logo_url); ?>" class="logo" alt="<?php echo e($user->company_name); ?> Logo">
<?php echo $__env->renderComponent(); ?>

<?php $__env->endSlot(); ?>
<p>
    Hola! Queriamos avisarte que ya ingreso nuevo stock para el artículo: <?php echo e($article->name); ?>.
</p>
<p>
	Puedes ingresar a ver el artículo presionando el botón de abajo.
</p>


<?php if(!is_null($article_url)): ?>
<?php $__env->startComponent('mail::button', ['url' => $article_url]); ?>
Ver artículo
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->slot('footer'); ?>
<?php $__env->startComponent('mail::footer'); ?>
© <?php echo e(date('Y')); ?> ComercioCity
<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\empresa-api\resources\views/emails/articles/advise.blade.php ENDPATH**/ ?>