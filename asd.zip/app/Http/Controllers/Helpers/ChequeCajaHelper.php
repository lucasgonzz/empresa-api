<?php

namespace App\Http\Controllers\Helpers;

use App\Models\Cheque;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Helpers\UserHelper;

class ChequeCajaHelper {

    static function actualizar_caja($cheque, $caja_id) {
        
        
       
    }

}