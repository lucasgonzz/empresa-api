<?php

return [
    'access_token' => env('TN_ACCESS_TOKEN'),
    'store_id'     => env('TN_USER_ID'),
];
