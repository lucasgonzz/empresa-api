@foreach($mensajes as $mensaje)
{{ $mensaje }}
@endforeach