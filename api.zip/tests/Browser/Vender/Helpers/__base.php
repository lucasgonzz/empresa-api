<?php

namespace Tests\Browser\Vender\Helpers;

class __base {

    function __construct($browser) {

        $this->browser = $browser;

    }
    
}
