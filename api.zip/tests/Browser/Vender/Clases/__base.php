<?php

namespace Tests\Browser\Vender\Clases;

class __base {

    function __construct($browser) {

        $this->browser = $browser;

    }
    
}
