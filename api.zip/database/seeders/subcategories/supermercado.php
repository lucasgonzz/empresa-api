<?php

$sub_categories = [
    [
        'category_name'     => 'Almacen',
        'category_id'       => 1,
        'sub_categories'    => [
            'Yerbas',
            'Mates',
        ],
    ],
    [
        'category_name'     => 'Gaseosas',
        'category_id'       => 2,
        'sub_categories'    => [
            'Cocacola',
            'Manaos',
        ],
    ],
];