<?php

namespace App\Http\Controllers\Helpers;

use App\Http\Controllers\AfipWsController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\CommissionController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\CurrentAcountController;
use App\Http\Controllers\Helpers\AfipHelper;
use App\Http\Controllers\Helpers\Afip\AfipNotaCreditoHelper;
use App\Http\Controllers\Helpers\ArticleHelper;
use App\Http\Controllers\Helpers\CurrentAcountAndCommissionHelper;
use App\Http\Controllers\Helpers\CurrentAcountFromSaleHelper;
use App\Http\Controllers\Helpers\CurrentAcountHelper;
use App\Http\Controllers\Helpers\DiscountHelper;
use App\Http\Controllers\Helpers\GeneralHelper;
use App\Http\Controllers\Helpers\MessageHelper;
use App\Http\Controllers\Helpers\Numbers;
use App\Http\Controllers\Helpers\SaleModificationsHelper;
use App\Http\Controllers\Helpers\UserHelper;
use App\Http\Controllers\Helpers\comisiones\ComisionesHelper;
use App\Http\Controllers\Helpers\sale\ArticlePurchaseHelper;
use App\Http\Controllers\Helpers\sale\ComboHelper;
use App\Http\Controllers\Helpers\sale\PromocionVinotecaHelper;
use App\Http\Controllers\Helpers\sale\SaleCajaHelper;
use App\Http\Controllers\Helpers\sale\SaleTotalesHelper;
use App\Http\Controllers\Helpers\sale\UpdateHelper;
use App\Http\Controllers\SaleController;
use App\Http\Controllers\SellerCommissionController;
use App\Http\Controllers\StockMovementController;
use App\Models\AfipTicket;
use App\Models\Article;
use App\Models\ArticleVariant;
use App\Models\Cart;
use App\Models\Client;
use App\Models\Commissioner;
use App\Models\CreditAccount;
use App\Models\CurrentAcount;
use App\Models\Discount;
use App\Models\Sale;
use App\Models\SaleType;
use App\Models\SellerCommission;
use App\Models\Service;
use App\Models\StockMovement;
use App\Models\User;
use App\Models\Variant;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;


class SaleHelper extends Controller {

    static function set_total_sales($user_id) {

        $sales = Sale::where('user_id', $user_id)
                        ->orderBy('created_at', 'ASC')
                        ->get();

        echo count($sales).' ventas <br> ';

        foreach ($sales as $sale) {
            
            $sale->total = Self::getTotalSale($sale);
            $sale->timestamps = false;

            $sale->save();
        }

        echo 'Termino <br> ';
    }

    static function update_total_sale($sale) {
        $sale->total = Self::getTotalSale($sale);
        $sale->save();
    }

    static function get_se_esta_confirmando($request, $sale) {
        if ($request->confirmed && $sale->checked) {
            return true;
        }
        return false;
    }

    static function get_terminada($to_check, $fecha_entrega) {
        if (UserHelper::hasExtencion('check_sales') && $to_check) {
            return 0;
        }

        if (UserHelper::hasExtencion('ventas_con_fecha_de_entrega') && $fecha_entrega) {
            return 0;
        }

        return 1;
    }

    static function get_terminada_at($to_check, $fecha_entrega) {
        if (Self::get_terminada($to_check, $fecha_entrega)) {
            return Carbon::now();
        }
        return null;
    }

    static function check_guardad_cuenta_corriente_despues_de_facturar($sale, $instance) {
        if (UserHelper::hasExtencion('guardad_cuenta_corriente_despues_de_facturar')
            && !Self::al_cliente_se_le_factura_en_el_acto($sale) ) {
            $sale->save_current_acount = 0;
            $sale->save();
        }
    }

    static function al_cliente_se_le_factura_en_el_acto($sale) {
        if (!is_null($sale->client) && $sale->client->pasar_ventas_a_la_cuenta_corriente_sin_esperar_a_facturar) {
            return true;            
        }
        return false;
    }

    static function setPrinted($instance, $sale, $confirmed, $user) {
        if (UserHelper::hasExtencion('check_sales', $user) && $confirmed) {
            $sale->printed = 1;
            $sale->save();
            $instance->sendAddModelNotification('Sale', $sale->id, false);
        }
    }

    static function log_client($sale) {
        $client = $sale->client;
        if (!is_null($client)) {
            Log::info('La venta '.$sale->id.' tiene el cliente: '.$client->name.'. Id: '.$client->id);
        }
    }

    static function log_articles($sale, $articles) {
        Log::info('La venta '.$sale->id.' tiene estos articulos:');
        foreach ($articles as $article) {
            Log::info('Id: '.$article->id.'. '.$article->name.'. amount: '.$article->pivot->amount.'. checked_amount: '.$article->pivot->checked_amount);
        }
    }

    static function updatePreivusClient($sale, $previus_client_id) {
        if (!is_null($sale->client_id) && $sale->client_id != $previus_client_id && !is_null($previus_client_id)) {
            CurrentAcountHelper::checkSaldos('client', $previus_client_id);
        }
    }

    static function sendUpdateClient($instance, $sale) {
        if (!is_null($sale->client_id) && !$sale->to_check && !$sale->checked) {
            $instance->sendAddModelNotification('Client', $sale->client_id);
        }
    }

    static function deleteSaleFrom($model_name, $model_id, $instance) {
        $sale = Sale::where($model_name.'_id', $model_id)
                        ->first();
        if (!is_null($sale)) {
            Log::info('Se quiere eliminar sale N° '.$sale->num.'. id: '.$sale->id.'. Por el empleado: '.Auth()->user()->name.', doc: '.Auth()->user()->doc_number);
            $sale->delete();
            $instance->sendDeleteModelNotification('sale', $sale->id, false);
        }
    }

    static function get_confirmed($to_check) {
        if (UserHelper::hasExtencion('check_sales') && $to_check) {
            return 0;
        }
        return 1;
    }

    static function getEmployeeId($request = null) {
        if (!is_null($request) && $request->employee_id != 0) {
            return $request->employee_id;
        }

        $user = Auth()->user();
        if (!is_null($user->owner_id)) {
            return $user->id;
        }
        return null;
    }

    /* 
        Retorno siempre null porque se va a empezar a usar siempre el array
        de current_acount_payment_methods
    */
    static function getCurrentAcountPaymentMethodId($request) {
        return null;
        if (is_null($request->client_id)) {
            return $request->current_acount_payment_method_id;
        }
        return null;
    }

    static function saveAfipTicket($sale) {
        if (!is_null($sale->afip_information_id) && $sale->afip_information_id != 0) {
            $ct = new AfipWsController(['sale' => $sale]);
            $afip_ticket_result = $ct->init();
            return $afip_ticket_result;
        } 
    }

    static function getSelectedAddress($request) {
        return !is_null($request->selected_address) ? $request->selected_address['id'] : null;
    }

    static function getNumSaleFromSaleId($sale_id) {
        $sale = Sale::where('id', $sale_id)
                    ->select('num')
                    ->first();
        if ($sale) {
            return $sale->num;
        }
        return null;
    }

    static function attachProperies($model, $request, $from_store = true, $previus_articles = null, $previus_combos = null, $previus_promos = null, $sale_modification = null, $se_esta_confirmando_por_primera_vez = false) {

        Log::info('attachProperies');

        
        Self::attachDiscounts($model, $request->discounts);
        Self::attachSurchages($model, $request->surchages);

        Self::attachArticles($model, $request->items, $previus_articles, $se_esta_confirmando_por_primera_vez);
        
        Log::info('1');

        Self::attachPromocionVinotecas($model, $request->items, $previus_promos);
        Self::attachCombos($model, $request->items, $previus_combos);
        Self::attachServices($model, $request->items);

        Self::attachSelectedPaymentMethods($model, $request);
        
        Log::info('2');
        if (!$from_store) {
            SaleModificationsHelper::attach_articulos_despues_de_actualizar($model, $sale_modification);
            
            /*
                * Si la venta ya esta confirmada
                y no es que se esta confirmando por primera vez
                (osea ya estaba confirmada antes de actualizarce)
                Recien ahi veo si se elimino algun articulo para regresar al stock
            */
            if (!$model->to_check && !$model->checked && !$se_esta_confirmando_por_primera_vez) {

                UpdateHelper::check_articulos_eliminados($model, $request->items, $previus_articles, $se_esta_confirmando_por_primera_vez);
            }
        }

        Log::info('3');
        /*
            * Si se esta confirmando, el total que llega de vender esta mal
                porque no tiene en cuenta las unidades chequedas, las cuales ahora
                pasan a ser las unidades reales del articulo en la venta
            * Entonces se setea el total desde aca para tener eso en cuenta
        */
        if ($se_esta_confirmando_por_primera_vez) {
            Self::update_total_sale($model);
        }


        Log::info('4');
        if ($from_store && !$model->to_check && !$model->checked) {
            
            Self::create_current_acount($model);
            
            Self::crear_comision($model);

            SaleCajaHelper::check_caja($model);

        } else {

            Self::checkNotaCredito($model, $request);
        }

        Log::info('5');


        $h = new ArticlePurchaseHelper();
        $h->set_article_purcase($model);

        SaleTotalesHelper::set_total_cost($model);
    }

    // Chequeo que no falten articulos como le suele pasar a Pack
    static function check_que_este_el_articulos($sale, $article) {

        $sale->load('articles');
        $article_sale = $sale->articles()->find($article['id']);
            
        if (!$article_sale) {
            Self::attachArticle($sale, $article);
          
            // Log::info('No se estaba agregando el articulo '.$article['name'].'. N° '.$article['num'].' a la venta N° '.$sale->num);
        } else if (isset($article['name'])) {
            Log::info('La venta N° '.$sale->num.' SI tiene el articulo '.$article['name']);
        }
    }
    // static function check_que_esten_todos_los_articulos($sale) {

    //     foreach($sale->stock_movements as $stock_movement) {
    //         $article = $sale->articles()->find($stock_movement->article_id);
            
    //         if (!$article) {
                
    //             $article_faltante = $stock_movement->article;

    //             $sale->articles()->attach($stock_movement->article_id, [
    //                 'amount'    => abs($stock_movement->amount),
    //                 'price'     => $article_faltante->final_price,
    //             ]);
    //             Log::info('No se estaba agregando el articulo '.$article_faltante->name.'. N° '.$article_faltante->num.' a la venta N° '.$sale->num);
    //         } else {
    //             Log::info('La venta N° '.$sale->num.' SI tiene el articulo '.$article->name);
    //         }
    //     }
    // }

    static function set_total_a_facturar($sale, $request) {

        if (
            !is_null($request->afip_information_id) 
            && $request->afip_information_id != 0
        ) {

            $afip_ticket = new AfipTicket();
            $afip_ticket->afip_information_id = $request->afip_information_id;
            $afip_ticket->afip_tipo_comprobante_id = $request->afip_tipo_comprobante_id;
            $afip_ticket->facturar_importe_personalizado = null;
            $afip_ticket->sale = $sale;


            $afip_helper = new AfipHelper($afip_ticket);
            $importes = $afip_helper->getImportes();
            Log::info('pidiendo total_a_facturar: '.$importes['total']);

            $sale->total_a_facturar = $importes['total'];
            $sale->save();
        }
    }

    static function attachSelectedPaymentMethods($sale, $request){

        if (is_null($sale->client_id) || $sale->omitir_en_cuenta_corriente) {
            $sale->current_acount_payment_methods()->detach();

            if (
                !$request->current_acount_payment_method_id
                && is_array($request->selected_payment_methods)
            ) {
                foreach ($request->selected_payment_methods as $payment_method) {

                    if (!is_null($payment_method['amount'])) {

                        $amount = $payment_method['amount'];

                        if ($payment_method['id'] == 5 
                            && isset($request->monto_credito_real)
                            && !is_null($request->monto_credito_real)) {

                            $amount = $request->monto_credito_real;
                        }

                        $caja_id = null;
                        if (isset($payment_method['caja_id'])
                            && $payment_method['caja_id'] != 0) {
                            $caja_id = $payment_method['caja_id'];
                        }
                        
                        $sale->current_acount_payment_methods()->attach($payment_method['id'],[
                            'amount'    => $amount,
                            'caja_id'   => $caja_id,
                        ]);
                    }
                }
            } else {

                $total = (float)$sale->total;

                if (!is_null($request->discount_amount)) {
                    $total += (float)$request->discount_amount;
                }

                $sale->current_acount_payment_methods()->attach($request->current_acount_payment_method_id, [
                    'amount'                => $total,
                    'discount_percentage'   => $request->discount_percentage,
                    'discount_amount'       => $request->discount_amount,
                    'caja_id'               => $request->caja_id,
                ]);
            }
        }

    }
    static function checkNotaCredito($sale, $request) {
        if ($request->save_nota_credito) {
            sleep(1);
            $haber = 0;

            foreach ($request->returned_items as $item) {

                // Log::info('item:');
                // Log::info($item);

                $total_item = (float)$item['price_vender'] * (float)$item['returned_amount'];

                if (!is_null($item['discount']) && $item['discount'] != 0) {
                    $total_item -= $total_item * $item['discount'] / 100;
                }

                /*
                    * Aplica los descuentos de la venta si:
                    La venta tiene descuentos 
                    Y
                    Si es un articulo (a los cuales SIEMPRE se le aplican los descuentos de la venta)
                    O (en caso que no sea un articulo, osea que es un SERVICIO) la venta tiene en TRUE discounts_in_services
                */
                if (
                    count($sale->discounts) >= 1
                    && (
                        (isset($item['is_article']) && $item['is_article'])
                        || $sale->discounts_in_services
                    )
                ) {


                    foreach ($sale->discounts as $discount) {

                        $total_item -= (float)$discount->pivot->percentage * $total_item / 100;
                    }

                }

                /*
                    * Aplica los recargos de la venta si:
                    La venta tiene recargos 
                    Y
                    Si es un articulo (a los cuales SIEMPRE se le aplican los recargos de la venta)
                    O (en caso que no sea un articulo, osea que es un SERVICIO) la venta tiene en TRUE surchages_in_services
                */
                if (
                    count($sale->surchages) >= 1
                    && (
                        (isset($item['is_article']) && $item['is_article'])
                        || $sale->surchages_in_services
                    )
                ) {


                    foreach ($sale->surchages as $surchage) {

                        $total_item += (float)$surchage->pivot->percentage * $total_item / 100;
                    }

                }


                $haber += $total_item;

            }

            $nota_credito = CurrentAcountHelper::notaCredito(
                $haber, 
                $request->nota_credito_description, 
                'client', 
                $request->client_id, 
                $sale->id, 
                $request->returned_items
            );

            CurrentAcountHelper::checkSaldos('client', $request->client_id);

            $ct = new Controller();
            $ct->sendAddModelNotification('client', $request->client_id, false);

            Self::returnToStock($sale, $nota_credito, $request->returned_items);

            if (!is_null($sale->afip_ticket)) {
                $afip_helper = new AfipNotaCreditoHelper($sale, $nota_credito);
                $afip_helper->init();
            }
        }
    }

    static function returnToStock($sale, $nota_credito, $items) {
        // Log::info('returnToStock para nota_credito:');
        // Log::info((array)$nota_credito);
        foreach ($items as $item) {
            if (
                isset($item['returned_amount']) 
                && !is_null($item['returned_amount']) 
                && (float)$item['returned_amount'] > 0
            ) {
                $ct = new StockMovementController();
                $request = new \Illuminate\Http\Request();
                
                $request->model_id = $item['id'];
                $request->to_address_id = $sale->address_id;
                $request->amount = $item['returned_amount'];
                $request->nota_credito_id = $nota_credito->id;
                $request->concepto = 'Nota credito Venta N° '.$sale->num;
                $ct->store($request);
            }
        }

    }

    static function attachDiscounts($sale, $discounts) {
        $sale->discounts()->detach();
        // $discounts = GeneralHelper::getModelsFromId('Discount', $discounts_id);
        foreach ($discounts as $discount) {
            $sale->discounts()->attach($discount['id'], [
                'percentage' => $discount['percentage'],
            ]);
        }
    }

    static function attachSurchages($sale, $surchages) {
        $sale->surchages()->detach();
        // $surchages = GeneralHelper::getModelsFromId('Surchage', $surchages_id);
        foreach ($surchages as $surchage) {
            $sale->surchages()->attach($surchage['id'], [
                'percentage' => $surchage['percentage']
            ]);
        }
    }

    static function check_deleted_articles_from_check($sale, $previus_articles) {
        $sale->load('articles');

        if ($sale->checked && !is_null($previus_articles)) {
            Log::info('previus_articles:');
            foreach ($previus_articles as $article) {
                Log::info($article->name);
            }
            foreach ($previus_articles as $previus_article) {
                $is_deleted = true;
                foreach ($sale->articles as $sale_article) {
                    if ($previus_article->id == $sale_article->id) {
                        $is_deleted = false;
                        Log::info('Se encontro en previus_articles el articulo id: '.$previus_article->id);
                    }
                }
                if ($is_deleted) {
                    Log::info('No se encontro el articulo en previus_articles id: '.$previus_article->id);
                    $article = [
                        'id'                    => $previus_article->id,
                        'amount'                => (float)$previus_article->pivot->amount,
                        'cost'                  => $previus_article->pivot->cost,
                        'price_vender'          => $previus_article->pivot->price,
                        'returned_amount'       => $previus_article->pivot->returned_amount,
                        'delivered_amount'      => $previus_article->pivot->delivered_amount,
                        'discount'              => $previus_article->pivot->discount,
                        'checked_amount'        => $previus_article->pivot->amount,
                        'created_at'            => Carbon::now(),
                    ];
                    Self::attachArticle($sale, $article);
                }
            }
        }
    }

    static function get_seller_id($request) {
        if (isset($request->seller_id)
            && !is_null($request->seller_id)
            && $request->seller_id != 0) {

            return $request->seller_id;
        }

        if (!is_null($request->client_id)) {

            $client = Client::find($request->client_id);

            if (!is_null($client->seller_id)) {

                return $client->seller_id;
            }
        }

        $employee_id = Self::getEmployeeId($request);
        if (Self::getEmployeeId($request)) {

            $employee = User::find($employee_id);
            if ($employee->seller_id) {
                Log::info('retornando seller_id en base al empleado '.$employee->name);
                return $employee->seller_id;
            }
        }

        return 0;
    }

    static function create_current_acount($sale) {
        if (!is_null($sale->client_id) 
            && $sale->save_current_acount
            && !$sale->omitir_en_cuenta_corriente) {
            
            $helper = new CurrentAcountFromSaleHelper($sale);
            $helper->crear_current_acount();
        }
    }

    static function crear_comision($sale) {
        if (!is_null($sale->seller_id)) {
            
            $helper = new ComisionesHelper($sale);
            $helper->crear_comision();
        }
    }

    static function attachArticles($sale, $articles, $previus_articles, $se_esta_confirmando_por_primera_vez) {
        
        foreach ($articles as $article) {
            if (isset($article['is_article'])) {

                if (isset($article['varios_precios']) && is_array($article['varios_precios'])) {

                    foreach ($article['varios_precios'] as $otro_precio) {

                        $otro_precio['id'] = $article['id'];

                        if ($otro_precio['amount'] == '') {
                            $otro_precio['amount'] = 1;
                        }

                        Self::attachArticle($sale, $otro_precio);

                    }
                } else {

                    $amount = Self::getAmount($sale, $article);
                    
                    if (($sale->to_check || $sale->checked) 
                        || (!is_null($amount) && $amount > 0) ) {

                        // Log::info('Agregando el articulos: '.$article['name']);
                        Self::attachArticle($sale, $article);
                    } else {
                        // Log::info('No se agrego articulo '.$article['name'].' a la venta N° '.$sale->num.'. Amount: '.$amount);
                    }

                }


                if (!$sale->to_check && !$sale->checked && Self::usa_stock($article)) {

                    $amount = Self::getAmount($sale, $article);

                    if (isset($article['article_variant_id'])) {
                        $article_variant_id = $article['article_variant_id'];
                    } else {
                        $article_variant_id = null;
                    }
                    
                    // if ($amount > 0) {
                        ArticleHelper::discountStock($article['id'], $amount, $sale, $previus_articles, $se_esta_confirmando_por_primera_vez, $article_variant_id);
                    // }
                }

                Self::check_que_este_el_articulos($sale, $article);

            }
        }
    }

    static function usa_stock($article) {
        $_article = Article::find($article['id']);
        if (!is_null($_article)) {
            return !is_null($_article->stock);
        }
        return false;
    }

    static function attachArticle($sale, $article) {
        
        $delivered_amount = Self::getDeliveredAmount($article);

        $amount = Self::getAmount($sale, $article);
        $cost = Self::getCost($sale, $article);
        $price = $article['price_vender'];

        $ganancia = (float)$price - (float)$cost;

        $sale->articles()->attach($article['id'], [
            'amount'                => $amount,
            'ganancia'              => $ganancia * $amount,
            'cost'                  => $cost,
            'price'                 => $price,
            'returned_amount'       => Self::getReturnedAmount($article),
            'delivered_amount'      => $delivered_amount,
            'discount'              => Self::getDiscount($article),
            'checked_amount'        => Self::getCheckedAmount($sale, $article),
            'article_variant_id'    => Self::getArticleVariantId($article),
            'variant_description'    => Self::getVariantDescription($article),
            'price_type_personalizado_id'    => Self::get_price_type_personalizado($article),
            'created_at'            => Carbon::now(),
        ]);

        if (!is_null($delivered_amount) && !$sale->en_acopio) {
            $sale->en_acopio = 1;
            $sale->save();
        }
    }

    static function updateItemsPrices($sale, $items) {
        foreach ($items as $item) {
            if (isset($item['is_article']) && $item['price_vender'] != '') {
                $sale->articles()->updateExistingPivot($item['id'], [
                                                        'price' => $item['price_vender'],
                                                    ]);
            } else if (isset($item['is_service']) && $item['price_vender'] != '') {
                $service = Service::find($item['id']);
                $service->price = $item['price_vender'];
                $service->save();
                $sale->services()->updateExistingPivot($item['id'], [
                                                        'price' => $item['price_vender'],
                                                    ]);
            }
        }
    }

    static function attachPromocionVinotecas($sale, $promocion_vinotecas, $previus_promos) {
        foreach ($promocion_vinotecas as $promo) {
            if (isset($promo['is_promocion_vinoteca'])) {
                $sale->promocion_vinotecas()->attach($promo['id'], [
                                                            'amount' => (float)$promo['amount'],
                                                            'price' => $promo['price_vender'],
                                                            'created_at' => Carbon::now(),
                                                        ]);
                PromocionVinotecaHelper::discount_stock_promocion_vinoteca($sale, $promo, $previus_promos);
            }
        }
    }

    static function attachCombos($sale, $combos, $previus_combos) {
        foreach ($combos as $combo) {
            if (isset($combo['is_combo'])) {
                $sale->combos()->attach($combo['id'], [
                                                            'amount' => (float)$combo['amount'],
                                                            'price' => $combo['price_vender'],
                                                            'created_at' => Carbon::now(),
                                                        ]);

                ComboHelper::discount_articles_stock($sale, $combo, $previus_combos);
            }
        }
    }

    static function attachServices($sale, $services) {
        foreach ($services as $service) {
            if (isset($service['is_service'])) {
                $sale->services()->attach($service['id'], [
                    'price' => $service['price_vender'],
                    'amount' => $service['amount'],
                    'returned_amount'   => Self::getReturnedAmount($service),
                    'discount' => Self::getDiscount($service),
                ]);
            }
        }
    }

    static function updateCurrentAcountsAndCommissions($sale) {

        Self::deleteCurrentAcountFromSale($sale);
        Self::deleteSellerCommissionsFromSale($sale);

        Self::create_current_acount($sale);
        
        Self::crear_comision($sale);

        if (!$sale->omitir_en_cuenta_corriente) {

            // $sale->client->pagos_checkeados = 0;
            // $sale->client->save();

            $credit_account = CreditAccount::where('model_name', 'client')
                                        ->where('model_id', $sale->client_id)
                                        ->where('moneda_id', $sale->moneda_id)
                                        ->first();

            CurrentAcountHelper::check_saldos_y_pagos($credit_account->id);
        }

    }

    static function deleteCurrentAcountFromSale($sale) {
        $current_acount = CurrentAcount::where('sale_id', $sale->id)
                                        ->whereNull('haber')
                                        ->first();
        if (!is_null($current_acount)) {



            /* 
                Chequeo si habia un pago especifico (con tu_pay_id) para esta venta
                Si lo habia, libero ese pago para que aporte a otras ventas
            */
            $pago = CurrentAcount::where('to_pay_id', $current_acount->id)
                                ->first();

            if ($pago) {
                $pago->to_pay_id = null;
                $pago->save();
            }


            // Elimino current_acount de la venta
            $current_acount->pagado_por()->detach();
            $current_acount->delete();
        }
    }

    static function deleteSellerCommissionsFromSale($sale) {
        $seller_commissions = SellerCommission::where('sale_id', $sale->id)
                                            ->whereNull('haber')
                                            ->pluck('id');
        SellerCommission::destroy($seller_commissions);
    }

    static function getDiscount($item) {
        if (isset($item['discount'])) {
            return $item['discount'];
        }
        return null;
    }

    static function getAmount($sale, $article) {
        if ($sale->confirmed && isset($article['checked_amount']) && !is_null($article['checked_amount'])) {
            return (float)$article['checked_amount'];
        }
        return (float)$article['amount'];
    }

    static function getCheckedAmount($sale, $article) {
        if (isset($article['checked_amount']) && !is_null($article['checked_amount'])) {
            if ($sale->confirmed && isset($article['checked_amount']) && !is_null($article['checked_amount']) && (float)$article['checked_amount'] > 0) {
                return null;
            }
            return $article['checked_amount'];
        }
        return null;
    }

    static function getArticleVariantId($article) {
        if (isset($article['article_variant_id']) && $article['article_variant_id'] != 0) {
            return $article['article_variant_id'];
        }
        return null;
    }

    static function get_price_type_personalizado($article) {
        if (isset($article['price_type_personalizado_id']) && $article['price_type_personalizado_id'] != 0) {
            return $article['price_type_personalizado_id'];
        }
        return null;
    }

    static function getVariantDescription($article) {
        if (isset($article['article_variant_id']) && $article['article_variant_id'] != 0) {
            $article_variant = ArticleVariant::find($article['article_variant_id']);
            
            if (!is_null($article_variant)) {
                return $article_variant->variant_description;
            }
        }
        return null;
    }

    static function getReturnedAmount($item) {
        if (isset($item['returned_amount'])) {
            return $item['returned_amount'];
        }
        return null;
    }

    static function getDeliveredAmount($item) {
        if (isset($item['delivered_amount'])) {
            return $item['delivered_amount'];
        }
        return null;
    }

    static function getCost($sale, $item) {
        $user = $sale->user;
        Log::info('getCost');

        if (is_object($item)) {
            $item = json_decode(json_encode($item), true);
        }

        $cost = null;

        // Si se esta actualizando, se retorna el valor que estaba guardado (ya cotizado)
        if (
            isset($item['pivot'])
            && isset($item['pivot']['cost'])
        ) {
            Log::info('retornando del pivot: '.$item['pivot']['cost']);
            $cost = (float) $item['pivot']['cost'];
            return $cost;
        }


        // Solo truvari
        if (
            !$cost
            && isset($item['presentacion'])
        ) {

            $item_cost = (float)$item['cost'];
            if (isset($item['costo_real'])) {
                $item_cost = (float)$item['costo_real'];
            }
            
            $cost =  $item_cost * (float)$item['presentacion'];
        }


        if (!$cost) {
            if (isset($item['costo_real'])) {
                $cost = (float)$item['costo_real'];
            } else if (isset($item['cost'])) {
                $cost = (float)$item['cost'];
            }
        }

        Log::info('cost: '.$cost);

        if ($cost > 0) {

            
            if ($sale->moneda_id == 1) {
                // Pesos
                if (
                    isset($item['cost_in_dollars']) 
                    && $item['cost_in_dollars'] == 1
                    // && (
                    //     $user
                    //     && $user->cotizar_precios_en_dolares == 0
                    // )
                ) {
                    $cost *= (float)$sale->valor_dolar;
                }

            } else if ($sale->moneda_id == 2) {

                if (
                    $item['cost_in_dollars'] == 0
                    || $item['cost_in_dollars'] == '0'
                    || is_null($item['cost_in_dollars'])
                ) {
                    $cost /= (float)$sale->valor_dolar;
                }
            } 
        }


        foreach ($sale->discounts as $discount) {
            $cost -= $cost * $discount->pivot->percentage / 100;
        }
        foreach ($sale->surchages as $surchage) {
            $cost += $cost * $surchage->pivot->percentage / 100;
        }

        return $cost;
    }

    static function getDolar($article, $dolar_blue) {
        if (isset($article['with_dolar']) && $article['with_dolar']) {
            return $dolar_blue;
        }
        return null;
    }

    static function detachItems($sale, $sale_modification) {

        SaleModificationsHelper::attach_articulos_antes_de_actualizar($sale, $sale_modification);

        // if (!$sale->to_check && !$sale->checked) {
        //     Self::restaurar_stock($sale);
        // }

        $sale->articles()->detach();
        $sale->combos()->detach();
        $sale->services()->detach();
        $sale->promocion_vinotecas()->detach();
    }

    static function restaurar_stock($sale) {
        foreach ($sale->articles as $article) {
            if (count($article->addresses) >= 1 && !is_null($sale->address_id)) {
                foreach ($article->addresses as $article_address) {
                    if ($article_address->pivot->address_id == $sale->address_id) {
                        $new_amount = $article_address->pivot->amount + $article->pivot->amount;
                        $article->addresses()->updateExistingPivot($article_address->id, [
                            'amount'    => $new_amount,
                        ]);
                    }
                }
            } else if (!is_null($article->stock)) {
                $stock = 0;
                $stock = (int)$article->pivot->amount;
                $article->stock += $stock;
                $article->save();
            }
            // Self::deleteStockMovement($sale, $article);
        }
    }

    static function deleteStockMovement($sale, $article) {
        $stock_movement = StockMovement::where('sale_id', $sale->id)
                                        ->where('article_id', $article->id)
                                        ->first();
        if (!is_null($stock_movement)) {
            $stock_movement->delete();
        }
    }

    static function getTotalSale($sale, $with_discount = true, $with_surchages = true, $with_seller_commissions = false, $load_info = false) {
        $total_articles = 0;
        $total_combos = 0;
        $total_services = 0;
        $total_promocion_vinotecas = 0;

        if ($load_info) {
            $sale->load('articles');
            $sale->load('combos');
            $sale->load('promocion_vinotecas');
            $sale->load('services');
            $sale->load('discounts');
            $sale->load('surchages');
        }
        
        // Log::info('getTotalSale');
        // Log::info(count($sale->articles).' articles');

        foreach ($sale->articles as $article) {
            $total_articles += Self::getTotalItem($article);
            Log::info('Sumando '.$total_articles.' de '.$article->name);
        }
        foreach ($sale->combos as $combo) {
            $total_combos += Self::getTotalItem($combo);
        }
        foreach ($sale->promocion_vinotecas as $promocion_vinoteca) {
            $total_promocion_vinotecas += Self::getTotalItem($promocion_vinoteca);
        }
        foreach ($sale->services as $service) {
            $total_services += Self::getTotalItem($service);
        }
        if ($with_discount) {
            foreach ($sale->discounts as $discount) {
                $total_articles -= $total_articles * $discount->pivot->percentage / 100;
                $total_combos -= $total_combos * $discount->pivot->percentage / 100;
                $total_promocion_vinotecas -= $total_promocion_vinotecas * $discount->pivot->percentage / 100;

                if ($sale->discounts_in_services) {
                    $total_services -= $total_services * $discount->pivot->percentage / 100;
                }
            }
        }
        if ($with_surchages) {
            foreach ($sale->surchages as $surchage) {
                $total_articles += $total_articles * $surchage->pivot->percentage / 100;
                $total_combos += $total_combos * $surchage->pivot->percentage / 100;
                $total_promocion_vinotecas += $total_promocion_vinotecas * $surchage->pivot->percentage / 100;

                if ($sale->surchages_in_services) {
                    $total_services += $total_services * $surchage->pivot->percentage / 100;
                }
            }
        }
        $total = $total_articles + $total_services + $total_combos + $total_promocion_vinotecas;
        if (!is_null($sale->percentage_card)) {
            $total += ($total * Numbers::percentage($sale->percentage_card));
        }

        if ($with_discount) {

            if ($sale->descuento > 0) {
                $total -= ($total * $sale->descuento / 100);
            }
        }

        if ($with_seller_commissions) {
            foreach ($sale->seller_commissions as $seller_commission) {
                $total -= $seller_commission->debe;
            }
        }
        return $total;
    }

    static function getTotalItem($item) {
        $amount = $item->pivot->amount;
        // if (!is_null($item->pivot->returned_amount)) {
        //     $amount -= $item->pivot->returned_amount;
        // }
        Log::info('getTotalItem:');
        Log::info('amount: '.$amount);
        Log::info('price: '.$item->pivot->price);
        $total = $item->pivot->price * $amount;
        Log::info('total: '.$total);
        if (!is_null($item->pivot->discount)) {
            $total -= $total * ($item->pivot->discount / 100);
        }
        return $total;
    }

    static function getTotalSaleFromArticles($sale, $articles) {
        $total = 0;
        foreach ($articles as $article) {
            if (!is_null($sale->percentage_card)) {
                $total += ($article->pivot->price * Numbers::percentage($sale->percentage_card)) * $article->pivot->amount;
            } else {
                $total += $article->pivot->price * $article->pivot->amount;
            }
        }
        return $total;
    }

    static function getTotalCostSale($sale) {
        $total = 0;
        foreach ($sale->articles as $article) {
            if (!is_null($article->pivot->cost)) {
                $total += $article->pivot->cost * $article->pivot->amount;
            }
        }
        return $total;
    }

    static function isSaleType($sale_type_name, $sale) {
        $sale_type = SaleType::where('user_id', UserHelper::userId())
                                    ->where('name', $sale_type_name)
                                    ->first();
        if (!is_null($sale_type) && $sale->sale_type_id == $sale_type->id) {
            return true;
        } 
        return false;
    }

    static function getPrecioConDescuento($sale) {
        // $discount = DiscountHelper::getTotalDiscountsPercentage($sale->discounts, true);
        $total = Self::getTotalSale($sale);
        foreach ($sale->discounts as $discount) {
            $total -= $total * Numbers::percentage($discount->pivot->percentage); 
        }
        return $total;
        // return Self::getTotalSale($sale) - (Self::getTotalSale($sale) * Numbers::percentage($discount));
    }

    static function getPrecioConDescuentoFromArticles($sale, $articles) {
        $discount = DiscountHelper::getTotalDiscountsPercentage($sale->discounts, true);
        $total = 0;
        foreach ($articles as $article) {
            if (!is_null($sale->percentage_card)) {
                $total += ($article->pivot->price * Numbers::percentage($sale->percentage_card)) * $article->pivot->amount;
            } else {
                $total += $article->pivot->price * $article->pivot->amount;
            }
        }
        return $total - ($total * Numbers::percentage($discount));
    }

    static function getTotalWithDiscountsAndSurchages($sale, $total_articles, $total_combos, $total_services) {
        foreach ($sale->discounts as $discount) {
            // Log::info('total_services: '.$total_services);
            if ($sale->discounts_in_services) {
                // Log::info('restando '.$total_services * Numbers::percentage($discount->pivot->percentage).' a los servicios');
                $total_services -= $total_services * Numbers::percentage($discount->pivot->percentage);
            } else {
                // Log::info('No se resto a los servicios');
            }
            // Log::info('total_services quedo en: '.$total_services);

            // Log::info('------------------------------------');
            // Log::info('total_articles: '.$total_articles);
            $total_articles -= $total_articles * Numbers::percentage($discount->pivot->percentage);
            // Log::info('total_articles quedo en: '.$total_articles);

            // Log::info('------------------------------------');
            // Log::info('total_combos: '.$total_combos);
            $total_combos -= $total_combos * Numbers::percentage($discount->pivot->percentage);
            // Log::info('total_combos quedo en: '.$total_combos);
        }
        foreach ($sale->surchages as $surchage) {
            if ($sale->surchages_in_services) {
                $total_services += $total_services * Numbers::percentage($surchage->pivot->percentage);
            }
            $total_articles += $total_articles * Numbers::percentage($surchage->pivot->percentage);
            $total_combos += $total_combos * Numbers::percentage($surchage->pivot->percentage);
        }
        if (!is_null($sale->order) && !is_null($sale->order->cupon)) {
            if (!is_null($sale->order->cupon->percentage)) {
                $total -= $total * $sale->order->cupon->percentage / 100;
            } else if (!is_null($sale->order->cupon->amount)) {
                $total -= $sale->order->cupon->amount;
            }
        }
        $total = $total_articles + $total_combos + $total_services;
        Log::info('------------------------------------');
        Log::info('retornando '.$total);

        return $total;
    }

    static function getTotalMenosDescuentos($sale, $total) {
        foreach ($sale->discounts as $discount) {
            $total -= $total * Numbers::percentage($discount->pivot->percentage);
        }
        return $total;
    }

}
