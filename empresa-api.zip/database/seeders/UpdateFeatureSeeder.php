<?php

namespace Database\Seeders;

use App\Models\UpdateFeature;
use Illuminate\Database\Seeder;

class UpdateFeatureSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $models = [
            [
                'name' => 'Elegir metodo de pago predeterminado',
                'description' => 'Desde la configuracion general, se podra establecer un metodo de pago predeterminado, para que luego de realizar una venta, el metodo de pago vuelva automaticamente a este.',
            ],
            [
                'name' => 'Articulos en OFERTA en la tienda',
                'description' => 'Cuando se seleccione un articulo para editar, habra un Check para indicar si ese articulo se encuentra en oferta, si se marca, ese articulo se mostrara en la tienda en la nueva seccion del inicio "OFERTAS".',
            ],
        ];
        foreach ($models as $model) {
            UpdateFeature::create([
                'name'          => $model['name'],
                'description'   => $model['description'],
            ]);
        }
    }
}
