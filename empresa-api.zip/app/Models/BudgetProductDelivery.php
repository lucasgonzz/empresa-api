<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BudgetProductDelivery extends Model
{
    protected $guarded = [];
}
