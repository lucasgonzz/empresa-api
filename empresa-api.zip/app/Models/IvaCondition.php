<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IvaCondition extends Model
{
    protected $guarded = [];

    function scopeWithAll($q) {
        
    }
}
