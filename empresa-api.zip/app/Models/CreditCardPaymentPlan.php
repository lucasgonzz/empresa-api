<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CreditCardPaymentPlan extends Model
{
    protected $guarded = [];
}
