<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CurrentAcountPaymentMethod extends Model
{
    protected $guarded = [];

    function scopeWithAll($q) {
        
    }
}
