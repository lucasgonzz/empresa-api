<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Description extends Model
{
    protected $guarded = [];

    function scopeWithAll($q) {
        
    }
}
