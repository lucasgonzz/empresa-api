<?php

namespace App\Http\Controllers\Helpers\database;

use App\Http\Controllers\Helpers\DatabaseHelper;
use App\Models\Article;
use App\Models\Description;
use App\Models\Image;
use App\Models\PriceChange;
use App\Models\StockMovement;

class DatabaseArticleHelper {

    static function copiar_articulos($user, $bbdd_destino, $from_id) {

        if (!is_null($user)) {

            $articles = Article::where('user_id', $user->id)
                                ->orderBy('id', 'ASC')
                                ->where('id', '>=', $from_id)
                                ->with('descriptions', 'images', 'price_changes' ,'stock_movements')
                                ->get();

            DatabaseHelper::set_user_conecction($bbdd_destino);

            foreach ($articles as $article) {
                $finded_article = Article::find($article->id);
                
                if (!is_null($finded_article)) {
                    $finded_article->delete();
                    $finded_article->forceDelete();
                }
            }
            
            foreach ($articles as $article) {
                $new_article = [
                    'id'                => $article->id,                     
                    'num'               => $article->num,                     
                    'bar_code'          => $article->bar_code,            
                    'provider_code'     => $article->provider_code,   
                    'provider_id'       => $article->provider_id,     
                    'category_id'       => $article->category_id,     
                    'sub_category_id'   => $article->sub_category_id,
                    'brand_id'          => $article->brand_id,            
                    'name'              => $article->name,                    
                    'slug'              => $article->slug,                    
                    'cost'              => $article->cost,                    
                    'cost_in_dollars'       => $article->cost_in_dollars,
                    'costo_mano_de_obra'        => $article->costo_mano_de_obra,
                    'provider_cost_in_dollars'      => $article->provider_cost_in_dollars,     
                    'apply_provider_percentage_gain'        => $article->apply_provider_percentage_gain,
                    'price'     => $article->price,                   
                    'percentage_gain'       => $article->percentage_gain,
                    'provider_price_list_id'        => $article->provider_price_list_id,     
                    'iva_id'        => $article->iva_id,              
                    'stock'     => $article->stock,                   
                    'stock_min'     => $article->stock_min,           
                    'online'        => $article->online,              
                    'in_offer'      => $article->in_offer,            
                    'default_in_vender'     => $article->default_in_vender,
                    'status'        => $article->status,             
                    'user_id'       => $article->user_id, 
                    'final_price'   => $article->final_price, 
                ];

                $created_article = Article::create($new_article);

                // Crear descripciones
                Self::description($created_article, $article);

                // Crear imagenes
                Self::images($created_article, $article);
                
                // Crear price_changes
                Self::price_changes($created_article, $article);

                // Crear stock_movements
                Self::stock_movements($created_article, $article);
                
                echo 'Se creo article id: '.$created_article->id.' </br>';
            }
        }
    }

    static function description($created_article, $article) {
        foreach ($article->descriptions as $description) {
            Description::create($description->toArray());
        }
    }

    static function images($created_article, $article) {
        foreach ($article->images as $image) {
            Image::create([
                'hosting_url' => $image->hosting_url,
                'imageable_id' => $article->id,
                'imageable_type' => $image->imageable_type,
                'color_id' => $image->color_id,
                'temporal_id' => $image->temporal_id,
            ]);
        }
    }

    static function price_changes($created_article, $article) {
        foreach ($article->price_changes as $price_change) {
            PriceChange::create($price_change->toArray());
        }
    }

    static function stock_movements($created_article, $article) {
        foreach ($article->stock_movements as $stock_movement) {
            StockMovement::create($stock_movement->toArray());
        }
    }
}