<?php

namespace App\Http\Controllers\Helpers;

class __name__Helper {
	
}