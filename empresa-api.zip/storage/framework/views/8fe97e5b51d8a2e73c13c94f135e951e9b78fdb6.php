<?php $__env->startComponent('mail::message'); ?>
# Error con la empresa: <?php echo e($owner_user->company_name); ?>.

Usuario: <?php echo e($auth_user->name); ?>. 
Dni <?php echo e($auth_user->doc_number); ?>.

# Error:

<?php $__env->startComponent('mail::panel'); ?>
<?php echo e($error); ?>

<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\empresa-api\resources\views/emails/errors/handler.blade.php ENDPATH**/ ?>