<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\empresa-api\resources\views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>