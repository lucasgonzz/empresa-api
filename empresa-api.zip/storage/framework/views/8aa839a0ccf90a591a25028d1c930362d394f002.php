<tr>
<td class="header">
<a href="https://comerciocity.com" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="https://comerciocity.com/img/logo.cc4cb183.png" class="comerciocity-logo" alt="Logo">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\wamp64\www\empresa-api\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>