<?php $__env->startComponent('mail::layout'); ?>

<?php $__env->slot('header'); ?>
<?php $__env->startComponent('mail::header', ['url' => $commerce->online]); ?>
<img src="<?php echo e($logo_url); ?>" class="logo" alt="Logo">
<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>
<p>
	<?php echo e($message); ?>

</p>

<?php $__env->slot('footer'); ?>
<?php $__env->startComponent('mail::footer'); ?>
© <?php echo e(date('Y')); ?> ComercioCity
<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\empresa-api\resources\views\emails\message-send.blade.php ENDPATH**/ ?>