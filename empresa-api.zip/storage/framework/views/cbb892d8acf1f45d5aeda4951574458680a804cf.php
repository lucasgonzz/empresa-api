<?php $__env->startComponent('mail::layout'); ?>

<?php $__env->slot('header'); ?>
<?php $__env->startComponent('mail::header', ['url' => env('APP_URL')]); ?>
<img src="<?php echo e($logo_url); ?>" class="logo">
<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>
<p>
	Has solicitado que te enviemos un código para recuperar tu contraseña.
</p>
<p>
	Aquí debajo te dejamos el código para que valides tu cuenta y puedas cambiar tu contraseña.
</p>

<?php $__env->startComponent('mail::panel'); ?>
<?php echo e($code); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->slot('footer'); ?>
<?php $__env->startComponent('mail::footer'); ?>
© <?php echo e(date('Y')); ?> ComercioCity
<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\empresa-api\resources\views\emails\password-reset.blade.php ENDPATH**/ ?>